/**
 *  Project: HipGISAXS (High-Performance GISAXS)
 *
 *  File: ff_ana_sawtooth_down.cpp
 *  Created: Jul 12, 2012
 *  Modified: Wed 08 Oct 2014 12:17:43 PM PDT
 *
 *  Author: Abhinav Sarje <asarje@lbl.gov>
 *  Developers: Slim Chourou <stchourou@lbl.gov>
 *              Abhinav Sarje <asarje@lbl.gov>
 *              Elaine Chan <erchan@lbl.gov>
 *              Alexander Hexemer <ahexemer@lbl.gov>
 *              Xiaoye Li <xsli@lbl.gov>
 *
 *  Licensing: The HipGISAXS software is only available to be downloaded and
 *  used by employees of academic research institutions, not-for-profit
 *  research laboratories, or governmental research facilities. Please read the
 *  accompanying LICENSE file before downloading the software. By downloading
 *  the software, you are agreeing to be bound by the terms of this
 *  NON-COMMERCIAL END USER LICENSE AGREEMENT.
 */

#include <boost/math/special_functions/fpclassify.hpp>

#include <woo/timer/woo_boostchronotimers.hpp>

#include <ff/ff_ana.hpp>
#include <common/enums.hpp>
#include <model/shape.hpp>
#include <model/qgrid.hpp>
#include <utils/utilities.hpp>
#include <numerics/numeric_utils.hpp>

namespace hig {

  /**
   * downwards sawtooth
   */
  bool AnalyticFormFactor::compute_sawtooth_down() {
    std::cerr << "uh-oh: you reach an unimplemented part of the code, compute_sawtooth_down"
          << std::endl;
    return false;
    /*for(shape_param_iterator_t i = params.begin(); i != params.end(); ++ i) {
      switch((*i).second.type()) {
        case param_edge:
        case param_xsize:
        case param_ysize:
        case param_height:
        case param_radius:
        case param_baseangle:
        default:
      } // switch
    } // for */

/*          Lx = 2 * dims(1);
            H = dims(2);
            L = 2 * dims(3);
            d =0.75;
            gamma =0.0;
            FF = Sawtooth_Finf_Matrix(QX,QY,QZ,H,L,d,gamma,Lx) .* exp(1i* (qx*T(1) + qy*T(2) + qz*T(3))) ; */

  } // AnalyticFormFactor::compute_sawtooth_down()

} // namespace hig

